/obj/item/weapon/card/money
	name = "Money Storage Card"
	desc = "A green card with a magentic strip and a display telling you how much money is in it."
	icon_state = "card_money"
	w_class = 1.0
	var/money_amount = 50

/obj/item/weapon/card/money/verb/read()
	set src in usr

	usr << text("This is a Money Storage Card. It has [money_amount] credits stored on it.")
	return

/obj/item/weapon/card/money/attack_self(mob/user as mob)
	for(var/mob/O in viewers(user, null))
		O.show_message(text("This is a Money Storage Card. It has [money_amount] credits stored on it."), 1)

	src.add_fingerprint(user)
	return

/obj/machinery/computer/vending_machine
	name = "Vending Machine"
	desc = "A Nanotransen VM-200 two-way vending machine, allowing you to both buy and sell things."
	icon = 'stationobjs.dmi'
	icon_state = "vending_machine"
	var buy_sell = -2

/obj/machinery/computer/vending_machine/attackby(obj/money_card as obj, mob/user as mob)
	if(istype(money_card, /obj/item/weapon/card/money))
		if (src.buy_sell > 0)
			money_card:money_amount = money_card:money_amount + src.buy_sell
			usr << "You now have [money_card:money_amount] credits."
			src.buy_sell = -2
		else
			usr << "You can buy:"
			var/for_sale = list("/obj/item/weapon/screwdriver","/obj/item/weapon/weldingtool","/obj/item/weapon/crowbar","/obj/item/weapon/wirecutters","/obj/item/weapon/tank/oxygentank","/obj/item/weapon/clothing/mask/gasmask","/obj/item/weapon/storage/toolbox","/obj/item/weapon/storage/firstaid/regular","/obj/item/weapon/wrench","/obj/item/weapon/multitool","/obj/item/weapon/cable_coil","/obj/item/weapon/clothing/glasses/regular","/obj/item/weapon/clothing/gloves/yellow","/obj/item/weapon/clothing/suit/black_firesuit","/obj/item/weapon/clothing/suit/sp_suit","/obj/item/weapon/storage/toolbox/electrical","/obj/item/weapon/tank/jetpack")
			var current
			for (current in for_sale)
				var current_path = text2path(current)
				var/obj/the_obj = new current_path( usr.loc )
				var obj_name = the_obj.name
				var obj_cost = the_obj.value
				del the_obj
				usr << "<A HREF='?src=\ref[src];user=\ref[user];money_card=\ref[money_card];buy=[current]'>[obj_name] ([obj_cost]c)</A>"
	else if (src.buy_sell == -2)
		usr << "Identifying object, please wait..."
		sleep(100)
		var obj_value = money_card:value
		var obj_name = money_card:name
		if (istype(money_card,/obj/item/weapon/card/id))
			if (money_card:last_paycheck >= (world.time + PAYCHECK_TIME))
				money_card:last_paycheck = world.time
				var position = money_card:assignment
				if (position == "Chaplain")
					src.buy_sell = 30
				else if (position == "Genetic Researcher")
					src.buy_sell = 40
				else if (position == "Toxin Researcher")
					src.buy_sell = 50
				else if (position == "Forensic Technician")
					src.buy_sell = 50
				else if (position == "Security Officer")
					src.buy_sell = 60
				else if (position == "Medical Doctor")
					src.buy_sell = 70
				else if (position == "Atmospheric Technician")
					src.buy_sell = 80
				else if (position == "Station Engineer")
					src.buy_sell = 80
				else if (position == "Head of Research")
					src.buy_sell = 90
				else if (position == "Head of Personnel")
					src.buy_sell = 90
				else if (position == "Captain")
					src.buy_sell = 100
				else
					src.buy_sell = 10
				usr << "Please insert your money storage card to collect your paycheck ([src.buy_sell] credits)."
			else
				usr << "You already collected your paycheck. Wait until the next paycheck collection time."
		else
			if (obj_value == -1)
				usr << "Unable to find the entry in the valuation database for the object you inserted."
			else
				usr << "The value of the [obj_name] you inserted is [obj_value] credits. Insert the object again to confirm your intent to sell it."
				src.buy_sell = -1
	else if (src.buy_sell == -1)
		usr << "Please insert your money storage card to collect the money."
		src.buy_sell = money_card:value
		del money_card
	else
		return ..()

/obj/machinery/computer/vending_machine/Topic(href,href_list)
	var/obj/item/weapon/card/money/money_card = locate(href_list["money_card"])
	var buy = href_list["buy"]
	var the_item = text2path(buy)
	var/obj/item = new the_item( usr.loc )
	var cost = item.value
	if (cost == -1)
		usr << "That item is not for sale."
		del item
	else
		if ((money_card.money_amount - cost) < 0)
			usr << "You don't have enough money for that."
			del item
		else
			money_card.money_amount = money_card.money_amount - cost